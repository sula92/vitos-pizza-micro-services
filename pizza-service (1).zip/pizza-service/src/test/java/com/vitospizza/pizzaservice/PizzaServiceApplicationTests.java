package com.vitospizza.pizzaservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PizzaServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
