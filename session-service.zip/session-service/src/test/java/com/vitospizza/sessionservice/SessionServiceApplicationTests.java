package com.vitospizza.sessionservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SessionServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
